#!/usr/bin/env node
/// <amd-module name="@angular/compiler-cli/src/ngcc/main-ngcc" />
export {};
