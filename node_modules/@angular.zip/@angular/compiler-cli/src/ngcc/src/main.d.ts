/// <amd-module name="@angular/compiler-cli/src/ngcc/src/main" />
export declare function mainNgcc(args: string[]): number;
