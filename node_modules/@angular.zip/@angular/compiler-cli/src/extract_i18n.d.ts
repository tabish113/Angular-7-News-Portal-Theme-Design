#!/usr/bin/env node
/// <amd-module name="@angular/compiler-cli/src/extract_i18n" />
import 'reflect-metadata';
export declare function mainXi18n(args: string[], consoleError?: (msg: string) => void): number;
