var convert = require('./convert'),
    func = convert('propertyOf', require('../get'));

func.placeholder = require('./placeholder');
module.exports = func;
