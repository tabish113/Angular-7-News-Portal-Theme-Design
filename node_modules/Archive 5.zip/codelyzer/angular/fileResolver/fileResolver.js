"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FileResolver = (function () {
    function FileResolver() {
    }
    return FileResolver;
}());
exports.FileResolver = FileResolver;
