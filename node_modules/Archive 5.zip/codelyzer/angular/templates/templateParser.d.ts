import { DirectiveDeclaration } from '../config';
export declare const parseTemplate: (template: string, directives?: DirectiveDeclaration[]) => any;
