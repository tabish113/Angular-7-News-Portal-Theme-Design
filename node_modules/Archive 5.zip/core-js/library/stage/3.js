require('../modules/es7.global');
require('../modules/es7.system.global');
require('../modules/es7.promise.finally');
module.exports = require('./4');
