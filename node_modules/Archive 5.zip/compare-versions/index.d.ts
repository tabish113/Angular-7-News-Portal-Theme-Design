declare namespace compareVersions { }
declare function compareVersions(firstVersion: string, secondVersion: string): 1 | 0 | -1;
export = compareVersions;