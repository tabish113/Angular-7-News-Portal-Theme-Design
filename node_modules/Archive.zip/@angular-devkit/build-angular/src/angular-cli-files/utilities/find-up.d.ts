export declare function findUp(names: string | string[], from: string, stopOnNodeModules?: boolean): string | null;
export declare function findAllNodeModules(from: string, root?: string): string[];
