# Installation
> `npm install --save @types/selenium-webdriver`

# Summary
This package contains type definitions for Selenium WebDriverJS ( https://github.com/SeleniumHQ/selenium/tree/master/javascript/node/selenium-webdriver ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/selenium-webdriver/v3

Additional Details
 * Last updated: Wed, 03 Apr 2019 01:26:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bill Armstrong <https://github.com/BillArmstrong>, Yuki Kokubun <https://github.com/Kuniwak>, Craig Nishina <https://github.com/cnishina>, Simon Gellis <https://github.com/SupernaviX>, Ben Dixon <https://github.com/bendxn>, Ziyu <https://github.com/oddui>.
