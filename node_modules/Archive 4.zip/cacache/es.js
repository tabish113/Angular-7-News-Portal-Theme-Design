'use strict'

module.exports = require('./locales/es.js')
