module.exports = require('./inplace')
