import { StorageCommandList } from '../interfaces';
export declare function storageFactory(type: 'session' | 'local'): StorageCommandList;
