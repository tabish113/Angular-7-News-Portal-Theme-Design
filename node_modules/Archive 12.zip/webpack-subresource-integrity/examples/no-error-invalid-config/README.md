# No exception when config is invalid
