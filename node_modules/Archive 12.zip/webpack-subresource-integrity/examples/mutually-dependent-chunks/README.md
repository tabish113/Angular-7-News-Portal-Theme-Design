# Mutually Dependent Chunks

Test case for issue #37
