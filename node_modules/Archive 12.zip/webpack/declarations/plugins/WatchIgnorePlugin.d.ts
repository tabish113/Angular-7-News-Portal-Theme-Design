/**
 * This file was automatically generated.
 * DO NOT MODIFY BY HAND.
 * Run `yarn special-lint-fix` to update
 */

/**
 * A list of RegExps or absolute paths to directories or files that should be ignored
 */
export type WatchIgnorePluginOptions = (string | RegExp)[];
